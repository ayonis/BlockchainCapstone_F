# Capstone: Real Estate Marketplace 


## Contract addresses on rinkeby test network and ABI
#### 1. Verifier 
```
 Deploying 'Verifier'
   --------------------
   > transaction hash:    0x7621142601c28d1893433da2a2c8eaf67c38e9a1e4bd8713ec0e
1a00127fd287
   > Blocks: 0            Seconds: 9
   > contract address:    0xEA76068437F4E54B72A08Aa5185e817E013844EF
   > block number:        7072446
   > block timestamp:     1598242517
   > account:             0x6c017cf603d1ECC3A4903262B296235b63B5e515
```
#### 2. SolnSquareVerifier
```
    Deploying 'SolnSquareVerifier'
   ------------------------------
   > transaction hash:    0xd6f266d544550dbcaf5cd8d209d020e4d2d15741800fcad53ac9
e93401219e0d
   > Blocks: 0            Seconds: 9
   > contract address:    0xC9a7447a432BBb91De7f582DB75414b4352E51F5
   > block number:        7072447
   > block timestamp:     1598242532
   > account:             0x6c017cf603d1ECC3A4903262B296235b63B5e515
```

### 3. Contract ABIs
 Can be found on `eth-contracts/build/contracts` folder of the project
 
## OpenSea MarketPlace Storefront link
- Original minter : `https://rinkeby.opensea.io/accounts/0x6c017cf603d1ecc3a4903262b296235b63b5e515`
- Buyer1 : `https://rinkeby.opensea.io/accounts/0xe06dc5c25cd66a7bcdc3b7a4c2e97f330cb95aaa`
Buyer2 : `https://rinkeby.opensea.io/accounts/0xf041ab72b92e3a694700c4e6176f6ba8657f8e3b`
Buyer3 : `https://rinkeby.opensea.io/accounts/0xc069535d28a3a4de3704cd73315bc133f9cc54af`
Buyer4 : `https://rinkeby.opensea.io/accounts/0x9f290910af622d435db6ff8013ea3f6b40efe06f`
Buyer5 : `https://rinkeby.opensea.io/accounts/0xc37e66d764fb9d3375b66c804b722b387fde2cbc`



### Prerequisites 

* [NodeJS]
* [ganache-UI]
* [truffle]
* MetaMask extension installed in your browser and few ethers on Rinkeby Test Network.
* [Docker]



## Authors

* **Abdelrhman Younis**

