// migrating the appropriate contracts
var verifier = artifacts.require('./verifier.sol');
//var SquareVerifier = artifacts.require("./SquareVerifier.sol");
var SolnSquareVerifier = artifacts.require("./SolnSquareVerifier.sol");

module.exports = function(deployer) {
   
  //deployer.deploy(SquareVerifier);
  deployer.then(async () => {
    await deployer.deploy(verifier);
    await deployer.deploy(SolnSquareVerifier, verifier.address, "EGY_House_Token", "EGYTKN");
    //...
});
};
