var json = require("./proof.json");
var SolnSquareVerifiercon = artifacts.require('SolnSquareVerifier');
var verifierCon = artifacts.require("verifier");

contract('Test Solution Square verifier', accounts => {

    const _symbol = "EGYTKN";
    const _name = "EGY_House_Token";
    const acc1 = accounts[0];
    const acc2 = accounts[1];
 

    describe('Test if a new solution can be added for contract - SolnSquareVerifier', function () {
		let addContract =true;
        beforeEach(async function () {
            const verifier = await verifierCon.new({from: acc1});
            this.contract = await SolnSquareVerifiercon.new(verifier.address, _name, _symbol, {from: acc1});

        });

       it(' Test if a new solution can be added for contract', async function () { 
	
		try{
		  await this.contract.addNewContractSolution(json.proof.A,json.proof.A_p,json.proof.B,json.proof.B_p,json.proof.C,json.proof.C_p,json.proof.H,json.proof.K,json.input,{from:acc2});
		   }
		 catch(e){
			   addContract = false
			 }
		assert.equal(addContract, true, "This Solution already exists ");
			});

  });

    describe('Test if an ERC721 token can be minted for contract - SolnSquareVerifier', function () {
        beforeEach(async function () {
          const verifier = await verifierCon.new({from: acc1});
          this.contract = await SolnSquareVerifiercon.new(verifier.address, _name, _symbol, {from: acc1});
        })

        it('Minting new ERC721 Token', async function () {

          let contractLogs = await this.contract.addNewContractSolution(json.proof.A,json.proof.A_p,json.proof.B,json.proof.B_p,json.proof.C,json.proof.C_p,json.proof.H,json.proof.K,json.input,{from:acc1});
         
          assert.equal(contractLogs.logs[0].args[1], acc1,"Senders adddress must match the Solution-address ");
          await this.contract.mintNewNFT(json.input[0],json.input[1],acc2,{from:acc1});
          let balance = await this.contract.balanceOf(acc2);
          assert.equal(balance, 1, " Token balance for the Account is Incorrect");

        });
    });

})
